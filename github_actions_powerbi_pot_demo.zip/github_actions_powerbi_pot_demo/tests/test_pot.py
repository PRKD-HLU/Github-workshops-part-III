"""Small unit tests for the POT demo pipeline."""
import csv
import tempfile
import unittest
from pathlib import Path
from scripts.build_pot_kpis import build

FIELDS = ['invoice_id', 'reporting_month', 'company_code', 'due_date', 'payment_date', 'amount_eur']


class PotTests(unittest.TestCase):
    def write_data(self, path, rows):
        with path.open('w', newline='', encoding='utf-8') as stream:
            writer = csv.DictWriter(stream, fieldnames=FIELDS)
            writer.writeheader()
            writer.writerows(rows)

    def test_correct_rate(self):
        with tempfile.TemporaryDirectory() as folder:
            source, target = Path(folder) / 'in.csv', Path(folder) / 'out.csv'
            rows = [
                dict(invoice_id='1', reporting_month='2026-09', company_code='0143', due_date='2026-09-15', payment_date='2026-09-14', amount_eur='100'),
                dict(invoice_id='2', reporting_month='2026-09', company_code='0143', due_date='2026-09-15', payment_date='2026-09-16', amount_eur='300'),
            ]
            self.write_data(source, rows)
            summary = build(source, target)
            with target.open(newline='', encoding='utf-8') as stream:
                result = list(csv.DictReader(stream))
            self.assertEqual(result[0]['company_code'], '0143')
            self.assertEqual(result[0]['pot_rate'], '0.5000')
            self.assertEqual(result[0]['amount_on_time_rate'], '0.2500')
            self.assertIn('VALIDATION PASSED', summary)

    def test_duplicate_invoice_fails(self):
        with tempfile.TemporaryDirectory() as folder:
            source, target = Path(folder) / 'in.csv', Path(folder) / 'out.csv'
            row = dict(invoice_id='1', reporting_month='2026-09', company_code='0143', due_date='2026-09-15', payment_date='2026-09-14', amount_eur='100')
            self.write_data(source, [row, row])
            with self.assertRaisesRegex(ValueError, 'duplicate invoice_id'):
                build(source, target)


if __name__ == '__main__':
    unittest.main()
