# GitHub Actions + Power BI: POT KPI Demo

**Cel warsztatowy:** GitHub Actions uruchamia testy danych i wylicza wskaźniki, a wygenerowany CSV jest gotowy do importu do Power BI.

> Wszystkie faktury i wartości są syntetyczne. POT w tym demo to **liczba faktur opłaconych nie później niż data wymagalności / liczba wszystkich faktur**. Ta uproszczona definicja może różnić się od firmowej metodologii POT.

## Pliki

| Ścieżka | Opis |
|---|---|
| `.github/workflows/pot-powerbi-demo.yml` | Workflow GitHub Actions |
| `data/invoices_demo.csv` | 108 fikcyjnych faktur, 3 spółki, 3 miesiące |
| `scripts/build_pot_kpis.py` | Walidacja danych i obliczanie KPI |
| `tests/test_pot.py` | Dwa automatyczne testy jednostkowe |
| `preview/pot_kpis.csv` | Gotowy podgląd wyników do Power BI (nie wymaga GitHuba) |
| `preview/validation_report_preview.txt` | Przykładowy raport z walidacji |

## 1. Test na GitHubie

1. Utwórz testowe repozytorium, np. `pot-powerbi-actions-demo`.
2. Sklonuj je przez **GitHub Desktop**.
3. Skopiuj zawartość tego projektu do lokalnego folderu repozytorium. Upewnij się, że został też skopiowany ukryty katalog `.github`.
4. Zrób **Commit to main** i **Push origin**.
5. Otwórz repozytorium w przeglądarce i przejdź do **Actions → POT KPI for Power BI**.
6. Kliknij **Run workflow**, wybierz `all` i potwierdź.
7. Otwórz zakończone uruchomienie. Powinno mieć status **Success**.
8. W dolnej części strony znajdź **Artifacts**. Pobierz `powerbi-pot-kpis` oraz `validation-report`.
9. Rozpakuj `powerbi-pot-kpis.zip`; plik `pot_kpis.csv` to dane gotowe do Power BI.

Workflow uruchamia się także po pushu zmian w `data/`, `scripts/`, `tests/` lub swojej konfiguracji na `main`. Na innych gałęziach można uruchamiać go ręcznie dopiero po pojawieniu się workflow na domyślnej gałęzi.

## 2. Pokaż, że da się zmienić miesiąc

1. **Actions → POT KPI for Power BI → Run workflow**.
2. Wybierz `2026-09` zamiast `all`.
3. Pobierz artefakt z nowego uruchomienia.
4. Otwórz `pot_kpis.csv`: będą w nim tylko 3 wiersze (po jednym dla każdej spółki).
5. Przy `all` są 9 wierszy (3 miesiące × 3 spółki).

## 3. Import danych do Power BI Desktop

1. Otwórz **Power BI Desktop → Home → Get data → Text/CSV**.
2. Wybierz pobrany `pot_kpis.csv` albo `preview/pot_kpis.csv` do szybkiego testu.
3. Kliknij **Transform data**. W Power Query ustaw:
   - `reporting_month` → **Date**;
   - `company_code` → **Text**, aby zachować zera wiodące (np. `0143`);
   - `total_invoices`, `on_time_invoices`, `late_invoices` → **Whole number**;
   - `pot_rate`, `amount_on_time_rate` → **Decimal number**;
   - kwoty `*_eur` → **Decimal number**.
4. Kliknij **Close & Apply**.
5. Tabelę najlepiej nazwać `pot_kpis` (poniższe formuły zakładają tę nazwę).

### Miary DAX

Utwórz nowe miary (Modeling → New measure):

```dax
POT % =
DIVIDE(SUM('pot_kpis'[on_time_invoices]), SUM('pot_kpis'[total_invoices]))
```

Formatuj tę miarę jako **Percentage, 1 decimal place**. Stosuj ważoną miarę zamiast średniej z kolumny `pot_rate`.

```dax
Total Invoices = SUM('pot_kpis'[total_invoices])
```

```dax
Late Invoices = SUM('pot_kpis'[late_invoices])
```

```dax
POT by Amount % =
DIVIDE(SUM('pot_kpis'[on_time_amount_eur]), SUM('pot_kpis'[total_invoice_amount_eur]))
```

### Trzy przykładowe wizualizacje

- **Card**: `POT %` (ogólny wskaźnik dla wybranych filtrów).
- **Line chart**: X = `reporting_month` (miesiąc, bez automatycznej hierarchii), Y = `POT %`, Legend = `company_code`.
- **Clustered column chart**: X = `company_code`, Y = `Total Invoices` oraz `Late Invoices`.

Dodaj **Slicer** po `reporting_month`. Wszystkie wizualizacje będą reagować na wybrany miesiąc. Przykładowy zagregowany wynik dla całego zbioru: **74/108 = 68,52%**.

## 4. Bonus: celowa awaria workflow

1. W `data/invoices_demo.csv` skopiuj jeden istniejący wiersz, zachowując ten sam `invoice_id`.
2. Zrób Commit i Push na `main`.
3. Otwórz zakładkę Actions. Workflow powinien zakończyć się statusem **Failure**.
4. W logach pojawi się `duplicate invoice_id`.
5. Artefakt `validation-report` zawiera opis błędu (jest wysyłany dzięki `if: always()`).
6. Usuń zduplikowany wiersz, Commit i Push. Workflow powinien ponownie przejść na zielono.

## 5. Uruchomienie bez GitHuba

W folderze głównym projektu:

```bash
python -m unittest discover -s tests -v
python scripts/build_pot_kpis.py --month all
```

Wynik pojawi się w `output/pot_kpis.csv` i `output/validation_report.txt`.

## Ograniczenie integracji z Power BI

Ta demonstracja **nie odświeża automatycznie opublikowanego raportu Power BI**. GitHub Actions generuje CSV jako **artifact**; plik trzeba pobrać i zaimportować/odświeżyć w Power BI Desktop. Automatyczne odświeżanie wymagałoby osobnego, zatwierdzonego procesu dostarczenia danych do lokalizacji dostępnej dla Power BI oraz konfiguracji odświeżania. Nie umieszczaj poufnych danych w publicznych repozytoriach ani artefaktach bez odpowiedniej polityki dostępu.
