#!/usr/bin/env python3
"""Build a Power BI-ready, aggregated POT KPI file from synthetic invoice data."""
import argparse
import csv
from collections import defaultdict
from datetime import date
from decimal import Decimal, InvalidOperation
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = (
    'invoice_id', 'reporting_month', 'company_code',
    'due_date', 'payment_date', 'amount_eur',
)
OUTPUT_FIELDS = (
    'reporting_month', 'company_code', 'total_invoices',
    'on_time_invoices', 'late_invoices', 'pot_rate',
    'total_invoice_amount_eur', 'on_time_amount_eur', 'amount_on_time_rate',
)


def build(input_path: Path, output_path: Path, month: str = 'all') -> str:
    with input_path.open('r', encoding='utf-8-sig', newline='') as file:
        reader = csv.DictReader(file)
        if not reader.fieldnames or not all(col in reader.fieldnames for col in REQUIRED):
            raise ValueError('Missing required CSV columns: ' + ', '.join(c for c in REQUIRED if c not in (reader.fieldnames or [])))
        raw = list(reader)

    seen = set()
    groups = defaultdict(lambda: {'total': 0, 'on_time': 0, 'amount': Decimal('0'), 'on_time_amount': Decimal('0')})
    used = 0
    for line, rec in enumerate(raw, start=2):
        try:
            ident = rec['invoice_id'].strip()
            report_month = rec['reporting_month'].strip()
            company_code = rec['company_code'].strip()
            due = date.fromisoformat(rec['due_date'].strip())
            paid = date.fromisoformat(rec['payment_date'].strip())
            amount = Decimal(rec['amount_eur'].strip())
            date.fromisoformat(report_month + '-01')
            if not ident:
                raise ValueError('empty invoice_id')
            if ident in seen:
                raise ValueError('duplicate invoice_id: ' + ident)
            seen.add(ident)
            if not (len(company_code) == 4 and company_code.isdigit()):
                raise ValueError('company_code must be four digits, e.g. 0143')
            if due.strftime('%Y-%m') != report_month:
                raise ValueError('reporting_month must match due_date month')
            if not amount.is_finite() or amount <= 0:
                raise ValueError('amount_eur must be positive and finite')
        except (KeyError, TypeError, InvalidOperation, ValueError) as exc:
            raise ValueError(f'Invalid input at CSV line {line}: {exc}') from exc
        if month != 'all' and report_month != month:
            continue
        used += 1
        group = groups[(report_month, company_code)]
        group['total'] += 1
        group['amount'] += amount
        if paid <= due:
            group['on_time'] += 1
            group['on_time_amount'] += amount

    if not used:
        raise ValueError(f'No invoices found for reporting_month={month}')
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open('w', encoding='utf-8', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=OUTPUT_FIELDS)
        writer.writeheader()
        for report_month, code in sorted(groups):
            g = groups[(report_month, code)]
            writer.writerow({
                'reporting_month': report_month + '-01',
                'company_code': code,
                'total_invoices': g['total'],
                'on_time_invoices': g['on_time'],
                'late_invoices': g['total'] - g['on_time'],
                'pot_rate': f"{g['on_time'] / g['total']:.4f}",
                'total_invoice_amount_eur': f"{g['amount']:.2f}",
                'on_time_amount_eur': f"{g['on_time_amount']:.2f}",
                'amount_on_time_rate': f"{g['on_time_amount'] / g['amount']:.4f}",
            })
    counts = sum(g['total'] for g in groups.values())
    paid_on_time = sum(g['on_time'] for g in groups.values())
    summary = (
        'VALIDATION PASSED\n'
        f'Invoice records checked: {len(raw)}\n'
        f'Records included in output: {counts}\n'
        f'Month filter: {month}\n'
        f'KPI rows created: {len(groups)}\n'
        f'On-time invoices: {paid_on_time}\n'
        f'Late invoices: {counts - paid_on_time}\n'
        f'Overall POT rate: {100 * paid_on_time / counts:.2f}%\n'
        'All input data is synthetic and for demonstration only.\n'
    )
    return summary


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--month', default='all', help='all or YYYY-MM')
    parser.add_argument('--input', type=Path, default=ROOT / 'data' / 'invoices_demo.csv')
    parser.add_argument('--output', type=Path, default=ROOT / 'output' / 'pot_kpis.csv')
    parser.add_argument('--report', type=Path, default=ROOT / 'output' / 'validation_report.txt')
    args = parser.parse_args()
    args.report.parent.mkdir(parents=True, exist_ok=True)
    try:
        summary = build(args.input, args.output, args.month)
    except (ValueError, OSError) as error:
        summary = f'VALIDATION FAILED\n{error}\n'
        args.report.write_text(summary, encoding='utf-8')
        print(summary)
        return 1
    args.report.write_text(summary, encoding='utf-8')
    print(summary)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
